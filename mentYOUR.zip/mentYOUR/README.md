# mentyour
Developing a solution to resolve the problems faced by Indian students of 9th to 12th grade battling career based confusions proposed by Department of School Education and Literacy under the Ministry Of Education, India through an AI powered mobile application that could act as a one-stop solution for the same.
