const Map<String, dynamic> CAREER_OPTIONS_SUMMARY = {
  "STEM": "Science, Technology, Engineering, & Mathematics",
  "Commerce & Management":
      "Vast plethora of gates involving Economics, Mathematics etc..",
  "Defense": "Military forces of the Republic of India",
  "Civil Services": "Permanent executive branch of the Republic of India",
  "Creative & Argumentative Studies":
      "Wide range of humanitarian & art based study",
  "Vocational Courses": "Teaching procedural knowledge",
  "Jobs as soon as possible": "Beginning working as soon as possible!"
};
