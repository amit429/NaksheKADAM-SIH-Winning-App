package com.bitnuggets.mentyour

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
